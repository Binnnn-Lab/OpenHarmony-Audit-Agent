"""Embedded CodeQL-AI implementation."""
